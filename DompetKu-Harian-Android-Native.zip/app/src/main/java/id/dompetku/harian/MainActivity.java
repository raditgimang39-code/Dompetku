package id.dompetku.harian;

import android.app.*;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.text.*;
import org.json.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int BG=Color.rgb(15,24,39), CARD=Color.rgb(26,40,59), MUTED=Color.rgb(157,174,195),
        GREEN=Color.rgb(42,211,165), RED=Color.rgb(255,119,133), WHITE=Color.WHITE, BLUE=Color.rgb(91,160,255);
    final String PREF="dompetku_daily", DATA="transactions", BUDGET="budget", GOAL="goal";
    JSONArray txs=new JSONArray();
    long budget=0, goal=0;
    LinearLayout root, body, nav;
    String page="home", filter="all";
    final NumberFormat nf=NumberFormat.getCurrencyInstance(new Locale("id","ID"));
    final Calendar cal=Calendar.getInstance();

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);nf.setMaximumFractionDigits(0);load();show();}
    void load(){
        var p=getSharedPreferences(PREF,0); budget=p.getLong(BUDGET,0);goal=p.getLong(GOAL,0);
        try{txs=new JSONArray(p.getString(DATA,"[]"));}catch(Exception e){txs=new JSONArray();}
    }
    void save(){var p=getSharedPreferences(PREF,0).edit();p.putString(DATA,txs.toString());p.putLong(BUDGET,budget);p.putLong(GOAL,goal);p.apply();}
    String money(long n){return nf.format(n).replace("Rp","Rp ");}
    long sum(String type, boolean monthOnly){
        long s=0;String m=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());
        for(int i=0;i<txs.length();i++){JSONObject o=txs.optJSONObject(i);if(o==null)continue;
            if(type.equals(o.optString("type")) && (!monthOnly||o.optString("date").startsWith(m)))s+=o.optLong("amount");}
        return s;
    }
    long balance(){return sum("income",false)-sum("expense",false);}
    TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void pad(View v,int n){v.setPadding(n,n,n,n);}
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    TextView btn(String s,int color,int fg){TextView t=txt(s,14,fg,true);t.setGravity(Gravity.CENTER);pad(t,14);t.setBackground(bg(color,22));return t;}
    void heading(String s){TextView t=txt(s,20,WHITE,true);t.setPadding(0,18,0,12);body.addView(t);}
    void card(View v){v.setBackground(bg(CARD,24));pad(v,18);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,12);body.addView(v,p);}
    void show(){
        root=col();root.setBackgroundColor(BG);
        LinearLayout top=row();pad(top,18);TextView brand=txt("◈  DompetKu",25,WHITE,true);top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView sub=txt("Keuangan harian",12,MUTED,false);top.addView(sub);root.addView(top);
        ScrollView scroll=new ScrollView(this);body=col();pad(body,18);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setBackgroundColor(CARD);
        String[][] tabs={{"home","Beranda"},{"transactions","Transaksi"},{"stats","Grafik"},{"plans","Anggaran"}};
        for(String[] tab:tabs){TextView b=txt(tab[1],12,page.equals(tab[0])?GREEN:MUTED,true);b.setGravity(Gravity.CENTER);pad(b,15);nav.addView(b,new LinearLayout.LayoutParams(0,-2,1));b.setOnClickListener(v->{page=tab[0];show();});}
        root.addView(nav);setContentView(root);
        switch(page){case "home":home();break;case "transactions":transactions();break;case "stats":stats();break;case "plans":plans();break;}
    }
    void home(){
        LinearLayout hero=col();hero.addView(txt("TOTAL SALDO",12,MUTED,true));TextView val=txt(money(balance()),30,WHITE,true);val.setPadding(0,8,0,16);hero.addView(val);
        LinearLayout r=row();LinearLayout a=col(),b=col();a.addView(txt("Pemasukan",12,MUTED,false));a.addView(txt(money(sum("income",true)),17,GREEN,true));b.addView(txt("Pengeluaran",12,MUTED,false));b.addView(txt(money(sum("expense",true)),17,RED,true));r.addView(a,new LinearLayout.LayoutParams(0,-2,1));r.addView(b,new LinearLayout.LayoutParams(0,-2,1));hero.addView(r);card(hero);
        LinearLayout actions=row();TextView inc=btn("+ Pemasukan",GREEN,BG),exp=btn("− Pengeluaran",0xff743e50,WHITE);
        actions.addView(inc,new LinearLayout.LayoutParams(0,-2,1));Space gap=new Space(this);actions.addView(gap,new LinearLayout.LayoutParams(8,1));actions.addView(exp,new LinearLayout.LayoutParams(0,-2,1));body.addView(actions);
        inc.setOnClickListener(v->addDialog("income"));exp.setOnClickListener(v->addDialog("expense"));
        heading("Ringkasan bulan ini");
        LinearLayout stats=row();stats.addView(metric("Masuk",money(sum("income",true)),GREEN),new LinearLayout.LayoutParams(0,-2,1));stats.addView(metric("Keluar",money(sum("expense",true)),RED),new LinearLayout.LayoutParams(0,-2,1));body.addView(stats);
        heading("Arus kas · 6 bulan terakhir");card(new MiniChart(txs));
        heading("Transaksi terbaru");addRows(true);
    }
    View metric(String title,String value,int color){LinearLayout c=col();c.addView(txt(title,12,MUTED,false));c.addView(txt(value,16,color,true));c.setBackground(bg(CARD,20));pad(c,15);return c;}
    void transactions(){
        heading("Semua transaksi");
        LinearLayout filters=row();String[] fs={"all","income","expense"};String[] labels={"Semua","Masuk","Keluar"};
        for(int i=0;i<fs.length;i++){final String f=fs[i];TextView t=btn(labels[i],filter.equals(f)?GREEN:CARD,filter.equals(f)?BG:WHITE);filters.addView(t,new LinearLayout.LayoutParams(0,-2,1));t.setOnClickListener(v->{filter=f;show();});}
        body.addView(filters);addRows(false);
        TextView add=btn("+ Tambah transaksi",GREEN,BG);body.addView(add);add.setOnClickListener(v->chooseType());
    }
    void chooseType(){new AlertDialog.Builder(this).setTitle("Tambah transaksi").setItems(new String[]{"Pemasukan","Pengeluaran"},(d,w)->addDialog(w==0?"income":"expense")).show();}
    void addRows(boolean recent){
        int shown=0;
        for(int i=txs.length()-1;i>=0;i--){JSONObject o=txs.optJSONObject(i);if(o==null)continue;String type=o.optString("type");if(!recent&&!filter.equals("all")&&!filter.equals(type))continue;
            LinearLayout item=row();item.setBackground(bg(CARD,18));pad(item,14);
            LinearLayout details=col();details.addView(txt(o.optString("name"),14,WHITE,true));details.addView(txt(o.optString("category")+" · "+o.optString("date"),11,MUTED,false));
            item.addView(details,new LinearLayout.LayoutParams(0,-2,1));boolean income=type.equals("income");item.addView(txt((income?"+ ":"− ")+money(o.optLong("amount")),14,income?GREEN:RED,true));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,8);body.addView(item,p);final int idx=i;
            item.setOnLongClickListener(v->{new AlertDialog.Builder(this).setTitle("Hapus transaksi?").setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{JSONArray n=new JSONArray();for(int j=0;j<txs.length();j++)if(j!=idx)n.put(txs.opt(j));txs=n;save();show();}).show();return true;});
            shown++;if(recent&&shown==5)break;
        }
        if(shown==0)body.addView(txt("Belum ada transaksi. Mulai catat keuanganmu.",13,MUTED,false));
    }
    void addDialog(String type){
        LinearLayout form=col();pad(form,8);
        EditText name=new EditText(this);name.setHint("Nama transaksi");form.addView(name);
        EditText amount=new EditText(this);amount.setHint("Nominal (Rp)");amount.setInputType(2);form.addView(amount);
        EditText category=new EditText(this);category.setHint("Kategori, mis. Makanan / Gaji");form.addView(category);
        EditText note=new EditText(this);note.setHint("Catatan (opsional)");form.addView(note);
        new AlertDialog.Builder(this).setTitle(type.equals("income")?"Pemasukan baru":"Pengeluaran baru").setView(form).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{
            try{String n=name.getText().toString().trim();long val=Long.parseLong(amount.getText().toString().trim());if(n.isEmpty()||val<=0)throw new Exception();
                JSONObject o=new JSONObject();o.put("name",n);o.put("amount",val);o.put("type",type);o.put("category",category.getText().toString().trim().isEmpty()?"Lainnya":category.getText().toString().trim());o.put("note",note.getText().toString());o.put("date",new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));txs.put(o);save();show();
            }catch(Exception e){Toast.makeText(this,"Isi nama dan nominal yang valid",Toast.LENGTH_SHORT).show();}
        }).show();
    }
    void stats(){
        heading("Grafik keuangan");
        card(new MiniChart(txs));
        heading("Ringkasan total");
        card(metric("Total pemasukan",money(sum("income",false)),GREEN));
        card(metric("Total pengeluaran",money(sum("expense",false)),RED));
        card(metric("Saldo saat ini",money(balance()),WHITE));
    }
    void plans(){
        heading("Anggaran & target");
        LinearLayout b=col();b.addView(txt("Anggaran pengeluaran bulanan",14,WHITE,true));b.addView(txt(budget==0?"Belum diatur":money(budget),22,GREEN,true));
        long spent=sum("expense",true);if(budget>0){ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setMax(100);pb.setProgress((int)Math.min(100,spent*100/budget));b.addView(pb);b.addView(txt("Terpakai "+money(spent)+" dari "+money(budget),12,MUTED,false));}card(b);
        TextView setB=btn("Atur anggaran",GREEN,BG);body.addView(setB);setB.setOnClickListener(v->numberDialog("Anggaran bulanan",budget,n->{budget=n;save();show();}));
        LinearLayout g=col();g.addView(txt("Target tabungan",14,WHITE,true));g.addView(txt(goal==0?"Belum diatur":money(goal),22,BLUE,true));card(g);
        TextView setG=btn("Atur target tabungan",BLUE,WHITE);body.addView(setG);setG.setOnClickListener(v->numberDialog("Target tabungan",goal,n->{goal=n;save();show();}));
    }
    interface LongAction{void run(long n);}
    void numberDialog(String title,long old,LongAction action){EditText e=new EditText(this);e.setInputType(2);e.setHint("Masukkan nominal");if(old>0)e.setText(""+old);new AlertDialog.Builder(this).setTitle(title).setView(e).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{try{action.run(Long.parseLong(e.getText().toString()));}catch(Exception ex){Toast.makeText(this,"Nominal tidak valid",0).show();}}).show();}
    class MiniChart extends View{
        Paint p=new Paint(3);JSONArray data;
        MiniChart(JSONArray a){super(MainActivity.this);data=a;setMinimumHeight(220);}
        protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();p.setColor(MUTED);p.setTextSize(30);c.drawText("Pemasukan vs pengeluaran",0,30,p);
            int n=6;long max=1;long[] ins=new long[n],outs=new long[n];Calendar now=Calendar.getInstance();
            for(int k=0;k<n;k++){Calendar m=(Calendar)now.clone();m.add(Calendar.MONTH,k-5);String key=new SimpleDateFormat("yyyy-MM",Locale.US).format(m.getTime());
                for(int i=0;i<data.length();i++){JSONObject o=data.optJSONObject(i);if(o==null||!o.optString("date").startsWith(key))continue;if(o.optString("type").equals("income"))ins[k]+=o.optLong("amount");else outs[k]+=o.optLong("amount");}max=Math.max(max,Math.max(ins[k],outs[k]));}
            float left=8,base=h-38,chartH=h-90,group=w/n,bar=Math.min(18,group*.24f);
            p.setColor(0xff405168);p.setStrokeWidth(1);c.drawLine(0,base,w,base,p);
            for(int k=0;k<n;k++){float x=left+k*group+group*.25f;float ih=(float)ins[k]/max*chartH,oh=(float)outs[k]/max*chartH;
                p.setColor(GREEN);c.drawRoundRect(x,base-ih,x+bar,base,8,8,p);p.setColor(RED);c.drawRoundRect(x+bar+5,base-oh,x+2*bar+5,base,8,8,p);
                Calendar m=(Calendar)now.clone();m.add(Calendar.MONTH,k-5);p.setColor(MUTED);p.setTextSize(20);String label=new SimpleDateFormat("MMM",new Locale("id","ID")).format(m.getTime());c.drawText(label,x-5,h-8,p);}
        }
    }
}
